import React from "react";
import SortTable from "./SortTable";
class Search extends React.Component{
    constructor(props){
        super(props);
        let d = this.props.data
        this.state = {
            data: d
        }
    }
    changeSearch(e){
        let newdata;
        if (document.getElementById("asdasdasd").value == "name"){
            newdata = this.props.data.filter((data) => {
                return data["name"].includes(e.target.value)
            }
            );
        } else {
            newdata = this.props.data.filter((data) => {
                return data["price"] <= parseInt(e.target.value) ? true : false 
            }
            );
        }
        
        
        this.setState({
            data: newdata
        })
    }
    render(){
        return <div>
            <input type="text" onChange={(e) => this.changeSearch(e)}/> <br />
            <select name="asdasdasd" id="asdasdasd">
                <option value="name" selected>name</option>
                <option value="price">price</option>
            </select>
            <SortTable data={this.state.data}></SortTable>
        </div>
    }
}

export default Search

import './App.css';
import Comments from './components/Comments';
import SortTable from './components/SortTable';
import Search from './components/Search';
import SignUpForm from './components/SignUpForm';
function App() {
  const data = [
    {"name": "Huawei watch", "img": "https://www.notebookcheck.net/fileadmin/Notebooks/Huawei/Watch_GT_3/4_to_3_Teaser_Huawei_Watch_GT_3_46_mm_Brown_Leather.jpg", "price": 123, "sale": 20, "new": true, "amount": 4, "description": 'Nice huawei watches'},
    {"name": "Samsung watch", "img": "https://images.samsung.com/is/image/samsung/latin-en-galaxy-watch-r810-sm-r810nzdatpa-frontgold-thumb-124537974?$480_480_PNG$", "price": 126, "sale": 0, "new": false, "amount": 3, "description": 'Nice samsung watches'},
    {"name": "Apple watch", "img": "https://store.storeimages.cdn-apple.com/4982/as-images.apple.com/is/FQKW2?wid=1673&hei=1353&fmt=jpeg&qlt=95&.v=1517334319257", "price": 1230000, "sale": 95, "new": false, "amount": 14, "description": 'Nice apple watches'},
  ]
  return (
    <div className="App">
      <SignUpForm></SignUpForm>
      <Search data={data}></Search>
    </div>
  );
}

export default App;

import React from "react";

class Comment{
    constructor(username, userimg, text, secret_msg, useremail){
        this.username = username
        this.userimg = userimg
        this.text = text
        this.date_created = new Date()
        this.date_updated = new Date()
        this.useremail = useremail
        this.secret_msg = secret_msg
    }
}

class Comments extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            comments: []
        }
        this.del_comment = this.del_comment.bind(this)
        this.upd_comment = this.upd_comment.bind(this)
    }

    add_comment(e){
        
        let text = document.getElementById("input_text").value
        document.getElementById("input_text").value = ""
        let username = document.getElementById("input_username").value
        document.getElementById("input_username").value = ""
        let useremail = document.getElementById("input_email").value
        document.getElementById("input_email").value = ""
        let userimg = document.getElementById("Userimg").value
        let secret_msg = document.getElementById("input_sk").value
        document.getElementById("input_sk").value = ""
        let comment = new Comment(username=username, userimg=userimg, text=text, secret_msg=secret_msg, useremail=useremail)
        let comments = this.state.comments
        comments.push(comment)
        this.setState({
            comments: comments,
        })
    }
    del_comment(comm){
        const index = this.state.comments.indexOf(comm);
        if (index > -1) {
            let comm = this.state.comments; // 2nd parameter means remove one item only
            comm.splice(index, 1)
            this.setState({
                comments: comm
            })
            this.forceUpdate()
        }
    }
    upd_comment(comm, new_text){
        const index = this.state.comments.indexOf(comm);
        if (index > -1) {
            // 1. Make a shallow copy of the items
            let items = this.state.comments;
            // 2. Make a shallow copy of the item you want to mutate
            let item = items[index];
            // 3. Replace the property you're intested in
            item.text = new_text;
            // 4. Put it back into our array. N.B. we *are* mutating the array here, but that's why we made a copy first
            items[index] = item;
            // 5. Set the state to our new copy
            this.setState({comments: items});
        }
    }

    render(){
        return <div>
            <div className="form">
                <input type="text" id="input_username" placeholder="Username"/>
                <br />
                <input type="email" id="input_email" placeholder="Usermail"/>
                <br />
                <input type="text" id="input_sk" placeholder="Secret key"/>
                <br />
                <select name="" id="Userimg">
                    <option value="https://pic.rutube.ru/user/4e/2d/4e2da89764c7fa207f99eac7d9232a22.jpg">Cat</option>
                    <option value="https://i1.sndcdn.com/avatars-000294588695-dofuqj-t500x500.jpg">Doggo</option>
                    <option value="https://i.kym-cdn.com/photos/images/facebook/001/480/729/087.jpeg">Parrot</option>
                </select>
                <br />
                <textarea name="" id="input_text" cols="30" rows="10" placeholder="Text">

                </textarea>
                <br />
                <input type="button" value="Submit" onClick={(e) => this.add_comment(e)}/>


            </div>
            <CommentsList comments={this.state.comments} del_comment={this.del_comment} upd_comment={this.upd_comment}></CommentsList>
        </div>
    }
}

class CommentsList extends React.Component{
    constructor(props){
        super(props)
    }
    render(){
        
        return <table>
            {this.props.comments.map((e, key) => <tr key={key}>
                <td><img src={e.userimg} alt=""  style={{height: "60px"}}/></td>
                <td>{e.username}</td>
                <td>{e.useremail}</td>
                <td>{e.date_created.getDate()}.{e.date_created.getMonth()}__{e.date_created.getHours()}:{e.date_created.getMinutes()}:{e.date_created.getSeconds()}</td>
                <td>{e.date_updated.getDate()}.{e.date_updated.getMonth()}__{e.date_updated.getHours()}:{e.date_updated.getMinutes()}:{e.date_updated.getSeconds()}</td>
                <td><DetailInfo el={e}></DetailInfo></td>
                <td><DelComment el={e} ondel={this.props.del_comment}></DelComment></td>
                <td><UpdComment el={e} onupda={this.props.upd_comment}></UpdComment></td>
            </tr>)}
        </table>
    }
}
class DetailInfo extends React.Component{
    constructor(props){
        super(props)
        this.state = {
            visibility: false,
            el: this.props.el
        }
    }

    change_v(e){
        this.setState({
            visibility: !this.state.visibility,
            el: this.props.el
        })
    }

    render(){
        if (this.state.visibility){
        return <div style={{zIndex: "123", position: "fixed", height: "200px", width: "600px", top: "100px", backgroundColor: "grey", color: "#FFF", borderRadius: "15px"}}>
            <h3>{this.props.el.username}</h3>
            <h4>{this.props.el.useremail}</h4>
                <p>{this.props.el.text}</p>
                <button onClick={(e) => this.change_v(e)}>Close</button>
        </div>} else {
            return <button onClick={(e) => this.change_v(e)}>Open</button>
        }
    }
}

class DelComment extends React.Component{
    constructor(props){
        super(props)
        this.state = {
            visibility: false,
            el: this.props.el
        }
    }
    change_v(e){
        this.setState({
            visibility: !this.state.visibility,
            el: this.props.el
        })
    }
    delee(e){
        alert(document.getElementById("secreet").value + " " + this.props.el.secret_msg)
        if (document.getElementById("secreet").value == this.props.el.secret_msg){
            this.props.ondel(this.props.el)
        } else {
            document.getElementById("secreet").value = "wrong key"
        }
    }
    render(){
        if (this.state.visibility){
            return <div>
                <input id="secreet" type="text" placeholder="secret_key"/>
                <button onClick={(e) => this.delee(e)}>del</button>
                <button onClick={(e) => this.change_v(e)}>Close</button>
            </div>
        } else {
            return <button onClick={(e) => this.change_v(e)}>del</button>
        }
    }
}
class UpdComment extends React.Component{
    constructor(props){
        super(props)
        this.state = {
            visibility: false,
            el: this.props.el
        }
    }
    change_v(e){
        this.setState({
            visibility: !this.state.visibility,
            el: this.props.el
        })
    }
    update(e){
        this.props.onupda(this.props.el, e.target.previousSibling.value)
        e.target.previousSibling.value = ""
    }
    render(){
        if (this.state.visibility){
            return <div>
                <input type="text" placeholder="New text"/>
                <button onClick={(e) => this.update(e)}>Update</button>
                <button onClick={(e) => this.change_v(e)}>Close</button>
            </div>
        } else {
            return <button onClick={(e) => this.change_v(e)}>upd</button>
        }
    }
}
export default Comments;
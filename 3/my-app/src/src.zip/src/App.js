import React from 'react';
import './App.css';
import Numb, { Number } from './PhoneInput/Numb';
import INDIA from './PhoneInput/INDIA';
import Phone from './PhoneInput/Phone';
import Table from './PhoneInput/Table';


const App = () => {
  return (
    <div>
    <Table/>
{/* <INDIA/> */}
</div>
  )
  
}
 export default App;
import { toHaveDisplayValue } from "@testing-library/jest-dom/dist/matchers";
import React from "react";
import NumperInput from "./NumperInput";
import SignUpEmailInput from "./SignUpEmailInput";
import SignUpPasswordInput from "./SignUpPasswordInput";

class SignUpForm extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            is_active: "BBB"
        }
        this.mail = false
        this.password = false
        this.change_submit = this.change_submit.bind(this)
        this.change_mail = this.change_mail.bind(this)
        this.dates = []
        this.monthes = []
        this.days = []
        for (let i=1990; i<=2022; i++){
            this.dates.push(<option value={i}>{i}</option>)
        }
        for (let i=1; i<12; i++){
            this.monthes.push(<option value={i}>{i}</option>)
        }
        for (let i=1; i<31; i++){
            this.days.push(<option value={i}>{i}</option>)
        }
        
    }

    change_submit(data){
        console.log(data)
        if (data){
            this.password = true
        } else {
            this.password = false
        }
        this.activate_submit()
    }
    change_mail(data){
        if(data){
            this.mail = true
        } else {
            this.mail = false
        }
        this.activate_submit()
    }

    activate_submit(){
        if (this.password && this.mail){
            this.setState({
                is_active: "AAA"
            })
        } else {
            this.setState({
                is_active: "BBB"
            })
        }
    }

    render(){
        return <form action="" method="post">
            <input type="text" placeholder="Name" id="name"/> <br />
            <input type="text" placeholder="Surame" id="surname"/> <br />
            <input type="text" placeholder="Otchestvo" id="2nd_name"/> <br />
            <SignUpEmailInput m_c={this.change_mail}></SignUpEmailInput>
            <br />
            <NumperInput></NumperInput>
            <br />
            <div className="mfchoise">
            <input type="radio" name="mf" id="mf1" value="male" />
            <label htmlFor="mf1">Male</label>
            <input type="radio" name="mf" id="mf2" value="female" />
            <label htmlFor="mf2">female</label>
            </div> <br />
            <SignUpPasswordInput pswd_v={this.change_submit}></SignUpPasswordInput>
            
            <select name="mnths" id="mnths">{this.dates}</select>
            <select name="" id="">{this.monthes}</select>
            <select name="" id="">{this.days}</select>
            
            <button type="submit"  style={this.state.is_active == "AAA" ? {display:'block'} : {display:'none'}}>Submit Form</button>
            
        </form>
    }

}

export default SignUpForm
import React from "react";
import PropTypes from 'prop-types';


class SignUpPasswordInput extends React.Component{
constructor(props){
    super(props)
    this.state = {
        valid_password: false,
        password: "",
        password_confirmed: false
    }
    
    this.props = props
}

check_password(e){
    let pswrd1 = e.target.value
    this.state.password = pswrd1
    let progress = document.getElementById("prgrs")
    let pswd_errs = document.getElementById("pswd_errs")
    pswd_errs.innerHTML = ""
    progress.value = 0
    this.state.valid_password = false
    // https://ru.stackoverflow.com/questions/533675/%D0%A0%D0%B5%D0%B3%D1%83%D0%BB%D1%8F%D1%80%D0%BD%D0%BE%D0%B5-%D0%B2%D1%8B%D1%80%D0%B0%D0%B6%D0%B5%D0%BD%D0%B8%D0%B5-%D0%B4%D0%BB%D1%8F-%D0%BF%D0%B0%D1%80%D0%BE%D0%BB%D1%8F-%D0%BE%D1%82-6-%D1%81%D0%B8%D0%BC%D0%B2%D0%BE%D0%BB%D0%BE%D0%B2-%D1%81-%D0%B8%D1%81%D0%BF%D0%BE%D0%BB%D1%8C%D0%B7%D0%BE%D0%B2%D0%B0%D0%BD%D0%B8%D0%B5%D0%BC-%D1%86%D0%B8%D1%84%D1%80-%D1%81%D0%BF%D0%B5%D1%86-%D1%81%D0%B8%D0%BC%D0%B2%D0%BE
    // регулярки взяты отсюда
    if (/(?=.*[0-9])/.test(pswrd1)){
        progress.value = 10
        if (/(?=.*[a-z])/.test(pswrd1)){
            progress.value = 35
            if (/(?=.*[A-Z])/.test(pswrd1)){
                progress.value = 65
                if (/(?=.*[!@#$%^&*])/.test(pswrd1)){
                    progress.value = 85
                    if (pswrd1.length >= 6) {
                        progress.value = 100
                        this.state.valid_password = true
                    } else {
                        pswd_errs.innerHTML = "Длинна пароля должна быть минимум 6 символов"
                    }
                } else {
                    pswd_errs.innerHTML = "Пароль не содержит хотя бы один спецсимвол;"
                }
            } else {
                pswd_errs.innerHTML = "Пароль не содержит хотя бы одну латинскую букву в верхнем регистре"
            }
        } else {
            pswd_errs.innerHTML = "Пароль не содержит хотя бы одну латинскую букву в нижнем регистре"
        }
    } else {
        pswd_errs.innerHTML = "Пароль должкен содержать минимум 1 цифру"
    }
    if (this.state.valid_password){
        pswd_errs.innerHTML = "Отличный пароль!"
    }
}

confirm_password(e){
    let aa = document.getElementById("cnfrmpswd")
    if (e.target.value = this.state.password){
        this.state.password_confirmed = true
        aa.innerHTML = "Пароли совпадают"
    } else {
        this.state.password_confirmed = false
        aa.innerHTML = "Пароли не совпадают"
    }
    console.log(this.state.password_confirmed)
    this.props.pswd_v(this.state.password_confirmed)
}

render(){
    return <div>
        <input onChange={(e)=>this.check_password(e)} type="text" placeholder="password" id="pswrd1" /> <br /><span id="pswd_errs"></span> <br />
        <input onChange={(e)=>this.confirm_password(e)} type="text" placeholder="repeat password" id="pswrd2"/> <br /> <span id="cnfrmpswd"></span> <br />
        <progress max="100" value="0" id="prgrs">
            Загружено на <span id="value">25</span>%
        </progress>
    </div>
}
}

SignUpPasswordInput.propTypes = {
    pswd_v: PropTypes.func
}

export default SignUpPasswordInput
import React from "react";

class CatalogItem extends React.Component{
    constructor(props){
        super(props);
    }
    render(){
        const sale = <small style={{backgroundColor: "red", borderRadius: "10px", padding: "10px", color: "#fff", fontSize: "large"}}>Skidka: {this.props.data.sale}%</small>
        return <div style={{border: "1px solid black", padding: "10px", margin: "10px"}}>
            <span>{this.props.data.new ? "новинка" : ""}</span>
            <h1>{this.props.data.name}</h1> {this.props.data.sale > 0 ? sale : ""}
            <br /> <br />
            <span>Price: {this.props.data.sale == 0 ? <span>{this.props.data.price}$</span> : <span><span style={{"textDecoration": "line-through"}}>{this.props.data.price}$</span><span style={{"marginLeft": "20px"}}>{this.props.data.price-this.props.data.price/100*this.props.data.sale}$</span></span>}</span><br />
            <img src={this.props.data.img} alt={this.props.data.name} style={{height: "80px"}}/>
            <br />
            <span>Stock: {this.props.data.amount}</span>
            <p>{this.props.data.description}</p>
        </div>
    }
}
export default CatalogItem
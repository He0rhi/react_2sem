import React from "react";
import PropTypes from 'prop-types';

class SignUpEmailInput extends React.Component{
    constructor(props){
        super(props);
    }

    validate_emai(e){
        if (!/^[a-zA-Z0-9]+@[a-zA-Z0-9]+\.[A-Za-z]+$/.test(e.target.value)) { 
            document.getElementById("MailAssertion").innerHTML = "input valid e-mail"
            this.props.m_c(false)
         }
        else {
            document.getElementById("MailAssertion").innerHTML = "E-mail seems valid"
            this.props.m_c(true)
        }
    }

    render(){
        return <div>
            <input onChange={(e)=>this.validate_emai(e)} type="mail" placeholder="input e-mail"/>
            <br />
            <span id="MailAssertion"></span>
            </div>
    }
}

SignUpEmailInput.propTypes = {
    m_c: PropTypes.func
}

export default SignUpEmailInput
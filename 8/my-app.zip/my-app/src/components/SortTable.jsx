import React from "react";
import CatalogItem from "./CatalogItem";
class SortTable extends React.Component{
    constructor(props){
        super(props);
        this.data = props.data
        this.sorted = {
            "name": false,
            "price": false,
            "stock": false
        }
        this.state = {
            "sorted_data": this.props.data
        }
    }
        

    sort_by_stock(e){
        if (this.sorted.stock){
            this.setState({"sorted_data": this.props.data.sort(function (a, b){return a["new"] - b["new"]})})
            this.sorted = {
                "name": false,
                "price": false,
                "stock": false
            }
            
        } else {
            this.setState({"sorted_data": this.props.data.sort(function (a, b){return a["inStock"] - b["inStock"]}).reverse()})
            this.sorted = {
                "name": false,
                "price": false,
                "stock": true
            }
            
        }
        
    }

    sort_by_price(e){
        if (this.sorted.price){
            this.setState({"sorted_data": this.props.data.sort(function (a, b){return b["price"] - a["price"]})})
            this.sorted = {
                "name": false,
                "price": false,
                "stock": false
            }
            
        } else {
            this.setState({"sorted_data": this.props.data.sort(function (a, b){return b["price"] - a["price"]}).reverse()})
            this.sorted = {
                "name": false,
                "price": true,
                "stock": false
            }
            
        }

    }

    sort_by_name(e){
        if (this.sorted.stock){
            this.setState({"sorted_data": this.props.data.sort(function (a, b){return b["name"] - a["name"]})})
            this.sorted = {
                "name": false,
                "price": false,
                "stock": false
            }
            
        } else {
            this.setState({"sorted_data": this.props.data.sort(function (a, b){return b["name"] - a["name"]}).reverse()})
            this.sorted = {
                "name": true,
                "price": false,
                "stock": false
            }
            
        }
    }

    render(){
        return <div><table>
            <tr><td><button onClick={(e) => this.sort_by_name(e)}>Name</button></td><td><button onClick={(e) => this.sort_by_price(e)}>Price</button></td><td><button onClick={(e) => this.sort_by_stock(e)}>Stock</button></td></tr>
        </table> {this.state.sorted_data.map((elememt, index) => <CatalogItem data={elememt}></CatalogItem>)}</div>
        
    }
}

export default SortTable